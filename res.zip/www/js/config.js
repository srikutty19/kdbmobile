var krms_config ={			
	'ApiUrl':"http://kdboys.chiarro.com/mobileapp/api",		
	'DialogDefaultTitle':"Kovai Delivery Boys",	
	'pushNotificationSenderid':"465251440510",	
	'facebookAppId':"882934511907337",
	'APIHasKey':""
};

